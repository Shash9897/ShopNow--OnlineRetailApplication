package org.example.dbms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class SignUpSceneController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField contactNumberField;

    @FXML
    private TextField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private Label userAdded;

    @FXML
    public void signUp() {
        String name = nameField.getText();
        String email = emailField.getText();
        String address = addressField.getText();
        String contactNumber = contactNumberField.getText();
        String password = passwordField.getText();

        // Check if the email already exists in the database
        boolean emailExists = checkEmailInDatabase(email);

        if (emailExists) {
            errorLabel.setText("Email already exists.");
            nameField.clear();
            emailField.clear();
            addressField.clear();
            contactNumberField.clear();
            passwordField.clear();
        } else {
            // Add the new user to the database
            int userId = getMaxUserId() + 1;
            addUserToDatabase(userId, name, email, address, contactNumber, password);
            // Display a message temporarily
            errorLabel.setText("User added with ID: " + userId);
            // Set a timer to clear the message after a few seconds
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), event -> {
                userAdded.setText(""); // Clear the message
                // Navigate to the initial scene or perform any other action
                SceneNavigator.loadScene(SceneNavigator.MAIN_SCENE);
            }));
            timeline.play();
        }
    }

    @FXML
    public void backToInitial() {
        SceneNavigator.loadScene(SceneNavigator.INITIAL_SCENE);
    }

    private boolean checkEmailInDatabase(String email) {
        String url = "jdbc:mysql://localhost:3306/PROJECT";
        String user = "root";
        String dbPassword = "Shashwat@9897";
        String query = "SELECT * FROM user WHERE email = ?";

        try (Connection conn = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet result = statement.executeQuery();
            return result.next(); // If result.next() is true, email exists
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Handle database connection error
        }
    }

    private int getMaxUserId() {
        String url = "jdbc:mysql://localhost:3306/PROJECT";
        String user = "root";
        String dbPassword = "Shashwat@9897";
        String query = "SELECT MAX(user_id) FROM user";

        try (Connection conn = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement statement = conn.prepareStatement(query);
             ResultSet result = statement.executeQuery()) {
            if (result.next()) {
                return result.getInt(1);
            } else {
                // No users found, return a default value or handle accordingly
                return 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection error
            return 0;
        }
    }


    private void addUserToDatabase(int userId, String name, String email, String address, String contactNumber, String password) {
        String url = "jdbc:mysql://localhost:3306/PROJECT";
        String user = "root";
        String dbPassword = "Shashwat@9897";
        String query = "INSERT INTO user (user_id, name, email, address, contact_number, password) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setInt(1, userId);
            statement.setString(2, name);
            statement.setString(3, email);
            statement.setString(4, address);
            statement.setString(5, contactNumber);
            statement.setString(6, password);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database error while adding user
        }
    }
}
