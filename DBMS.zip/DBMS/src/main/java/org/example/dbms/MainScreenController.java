package org.example.dbms;

public class MainScreenController {
}
