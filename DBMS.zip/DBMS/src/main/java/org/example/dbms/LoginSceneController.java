package org.example.dbms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginSceneController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    public void login() {
        String user_id = usernameField.getText();
        String password = passwordField.getText();

        // Check if username and password exist in the database
        boolean userExists = checkUserInDatabase(user_id, password);

        if (userExists) {
            // Navigate to the main screen
            SceneNavigator.loadScene(SceneNavigator.MAIN_SCENE);
        } else {
            // Clear fields and display error message
            usernameField.clear();
            passwordField.clear();
            errorLabel.setText("Username or password is incorrect.");
        }
    }

    @FXML
    public void backToInitial() {
        SceneNavigator.loadScene(SceneNavigator.INITIAL_SCENE);
    }

    private boolean checkUserInDatabase(String user_id, String password) {
        String url = "jdbc:mysql://localhost:3306/PROJECT";
        String user = "root";
        String dbPassword = "Shashwat@9897";
        String query = "SELECT * FROM user WHERE user_id = ? AND password = ?";

        try (Connection conn = DriverManager.getConnection(url, user, dbPassword);
             PreparedStatement statement = conn.prepareStatement(query)) {
            statement.setString(1, user_id);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();
            return result.next(); // If result.next() is true, user exists
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Handle database connection error
        }
    }
}
